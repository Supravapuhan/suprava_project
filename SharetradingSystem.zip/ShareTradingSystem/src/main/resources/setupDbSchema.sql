delimiter ;
DROP SCHEMA IF EXISTS `cs532_trading`; 
CREATE SCHEMA `cs532_trading` ;
use `cs532_trading`;


CREATE TABLE `cs532_trading`.`sts_comp_detail` (
  `comp_id` INT(11) NOT NULL,
  `comp_symbol` VARCHAR(10) NOT NULL,
  `comp_name` VARCHAR(45) NOT NULL,
  `avl_unit` INT(10) NOT NULL,
  `prc_per_unit` FLOAT NOT NULL,
  PRIMARY KEY (`comp_id`));

CREATE TABLE `cs532_trading`.`sts_buyer_info` (
  `trader_account_num` INT NOT NULL AUTO_INCREMENT,
  `trader_name` VARCHAR(45) NULL,
  `avl_amount` FLOAT NULL,
  `phone_number` VARCHAR(15) NULL,
  PRIMARY KEY (`trader_account_num`));

CREATE TABLE `cs532_trading`.`sts_trader_account` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `trader_account_num` INT(11) NOT NULL ,
  `comp_id` INT(11) NOT NULL,
  `buy_unit` INT(100) NULL,
  `total_price` FLOAT NULL,
  PRIMARY KEY (`id`));
  
  
INSERT INTO `cs532_trading`.`sts_buyer_info` (`trader_account_num`, `trader_name`, `avl_amount`, `phone_number`) VALUES ('111', 'Robert', '20000', '5102104345');
INSERT INTO `cs532_trading`.`sts_buyer_info` (`trader_account_num`, `trader_name`, `avl_amount`, `phone_number`) VALUES ('112', 'John', '30000', '5104104545s');

INSERT INTO `cs532_trading`.`sts_comp_detail` (`comp_id`, `comp_symbol`, `comp_name`, `avl_unit`, `prc_per_unit`) VALUES ('1', 'APL', 'Apple', '100', '50');
INSERT INTO `cs532_trading`.`sts_comp_detail` (`comp_id`, `comp_symbol`, `comp_name`, `avl_unit`, `prc_per_unit`) VALUES ('2', 'BOA', 'BOA', '200', '20');

INSERT INTO `cs532_trading`.`sts_trader_account` (`trader_account_num`, `comp_id`, `buy_unit`, `total_price`) VALUES ('111', '1', '10', '500');
