CREATE USER 'traderdb_user'@'localhost' IDENTIFIED BY 'spring';

GRANT ALL PRIVILEGES ON cs532_trading.* TO 'traderdb_user'@'localhost' WITH GRANT OPTION;

SHOW GRANTS FOR 'traderdb_user'@'localhost';