package sup.npu.sts.exceptions;

public class BuyerNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;

	public BuyerNotFoundException(String msg) {
		super(msg);
	}
}
