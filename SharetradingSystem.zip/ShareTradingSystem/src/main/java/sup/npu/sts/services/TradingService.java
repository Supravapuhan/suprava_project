package sup.npu.sts.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import sup.npu.sts.dao.TraderDaoI;
import sup.npu.sts.domain.Buyer;
import sup.npu.sts.domain.Company;
import sup.npu.sts.domain.Trader;

@Service
@Transactional
public class TradingService implements TradingServiceI {

	@Autowired
	@Qualifier("traderDaoJdbc")  // Use one qualifier or the other, but not both.  Uncomment Transactional annotation when using database
	TraderDaoI traderDao;
	
	public  Trader insertNewTrader(Trader newTrader){
		Trader insertedTrader;Buyer buyerObj;
	    Company compObj;
		String traderName;
		String compName;
		float totalprice;
		int buyingUnit;
		float pricePerUnit;
		
		traderName=newTrader.getTraderName();
    	buyerObj=getBuyerDetailByName(traderName);
    	System.out.println("buyer account number=="+buyerObj.getTraderAccountNo());
    	System.out.println("buyer avl amount=="+buyerObj.getAvlAmount());
    	newTrader.setTraderAccountNo(buyerObj.getTraderAccountNo());
    
        compName=newTrader.getCompanyName();
    	System.out.println("company name=="+compName);
    	compObj=getCompanyDetailByName(compName);
    	System.out.println("company account id=="+compObj.getCompId());
    	System.out.println("comp avl unit=="+compObj.getAvlUnit());
    	newTrader.setCompanyId(compObj.getCompId());
    	
    	buyingUnit=newTrader.getBuyingUnit();
    	pricePerUnit=compObj.getPricePerUnit();
    	totalprice=buyingUnit*pricePerUnit;
    	newTrader.setTotalPrice(totalprice);
    
		insertedTrader = traderDao.insertNewTrader(newTrader);
    	/*After trading update the buyer account balance*/
    	updateBuyerAvlAmount(newTrader,buyerObj);
    	/*Update the company unit after purchaged by trader*/
    	updateCompanyAvlUnit(newTrader,compObj);
		
		return insertedTrader;
		
	}

	public int updateCompanyAvlUnit(Trader newTrader, Company compObj) {
		int rowsaffected;
		rowsaffected=traderDao.updateCompanyAvlUnit(newTrader, compObj);
		return rowsaffected;
		
	}

	public int updateBuyerAvlAmount(Trader newTrader, Buyer buyerObj) {
		int rowsaffected;
		rowsaffected=traderDao.updateBuyerAvlAmount(newTrader, buyerObj);
		return rowsaffected;
		

	}

	@Override
	public Buyer getBuyerDetailByName(String traderName) {
		Buyer buyer;
		buyer=traderDao.getBuyerDetailByName(traderName);
		return buyer;
	}

	@Override
	public Company getCompanyDetailByName(String compName) {
		Company company;
		company=traderDao.getCompanyDetailByName(compName);
		return company;
	}

	@Override
	public List<Trader> getTradingList(String traderName) {
		System.out.println("inside trader service");
		List<Trader>  traderList;
		traderList=traderDao.getTradingList(traderName);
		return traderList;
		}

	@Override
	public Trader removeTraderWithId(long id) {
		Trader trader;
		trader=traderDao.removeTraderWithId(id);
		return trader;
	}



}
