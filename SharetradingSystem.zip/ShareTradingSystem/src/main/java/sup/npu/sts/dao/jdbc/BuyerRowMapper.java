package sup.npu.sts.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import sup.npu.sts.domain.Buyer;

public class BuyerRowMapper implements RowMapper<Buyer> {

	public Buyer mapRow(ResultSet resultSet, int row) throws SQLException {
		int traderAccountNo;
		float avlAmount;
		Buyer buyer;
		
		traderAccountNo = resultSet.getInt("trader_account_num");
		avlAmount = resultSet.getFloat("avl_amount");
		
		buyer = new Buyer();
		buyer.setTraderAccountNo(traderAccountNo);
		buyer.setAvlAmount(avlAmount);				
		return buyer;
	}

}
