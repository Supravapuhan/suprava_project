package sup.npu.sts.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import sup.npu.sts.domain.Buyer;
import sup.npu.sts.domain.Company;
import sup.npu.sts.domain.Trader;
import sup.npu.sts.services.TradingServiceI;

/*  Go to the home page:  http://localhost:8080/tradingapp
 *  
 */
@Controller
public class TraderController {
	@Autowired
	private TradingServiceI traderService;

	private static final Logger logger = LoggerFactory.getLogger(TraderController.class);
	
	@RequestMapping(value = "/newTradingDataForm", method = RequestMethod.GET)
	public String newTraderDataForm(HttpSession session) {
		logger.info("Welcome to trader controller");
		
		session.invalidate();   /* If there is an existing session remove it so that we'll simulate a new user at this point.  */
		return "tradingForm";
	}
	
	

	@RequestMapping(value = "/processtraderform", method = RequestMethod.POST)
	public ModelAndView editOrStoreTraderform(Trader newTrader,HttpSession session) 
	{
		session.setAttribute("trader", newTrader);
		logger.info("value of trader name==="+newTrader.getCompanyName());
		Trader insertedTrader;
		ModelAndView modelView;
	
		 insertedTrader=traderService.insertNewTrader(newTrader);
		 logger.info("Adding new trader in processtraderform:   " + insertedTrader.getTotalPrice());
		modelView = new ModelAndView("newTraderInsertSuccess");
		//modelView.addObject("trader", insertedTrader);
		
		return modelView;
	}
	
	
	@RequestMapping(value = "/listTradings", method = RequestMethod.GET)
	public ModelAndView processtraderprofileform(String traderName) 
	{
		List<Trader> traderList;
		ModelAndView modelView;
		
		traderList = traderService.getTradingList(traderName);
		modelView = new ModelAndView("viewTradingList");
		modelView.addObject("traderName", traderName);
		modelView.addObject("traderList", traderList);
		return modelView;
		
	}
	
	
	@RequestMapping(value = "/viewTraderProfile", method = RequestMethod.GET)
	public String traderInfoForm() {
		return "entertraderInfo";
	}
	
	

}
