package sup.npu.sts.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.log4j.Logger;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

import sup.npu.sts.domain.Trader;

/* This is code that would appear on the Client side.   Remember that before you can run this, you must
 * have your Rest Server running!
 */
public class TradingServicesClient {
	static private Logger logger = Logger.getLogger(TradingServicesClient.class);
	private static String TRADER_SERVICES_URL = "http://localhost:8080/tradingapp/webservices/traderestapp/trader/";
	private static Client authclient=null;  /* Required for JAX-RS authorization processing -- client will add Authorization Header */
	private static Client client=null;  
	
	public static void main(String args[]) {
		testLookupTrader();
//		testDelete();
//		testPost();
	}
	
	
	/* Client that will add an Authorization header */
	private static Client getClientWithAuth() {
		if (authclient == null) {
			authclient = ClientBuilder.newClient();
			/* Dummy user/password that should be overridden in the actual invocations */
			HttpAuthenticationFeature authFeature = HttpAuthenticationFeature.basic("user", "password");
			authclient.register(authFeature);
		}
		
		return authclient;
	}
	
	/* Client that will not add the authorization header */
	private static Client getClient() {
		if (client == null) {
			client = ClientBuilder.newClient();
		}
		
		return client;
	}
	
	public static Trader testLookupTrader() {
	String traderName="Robert";  /* Just some hardcoded test data */
		int responseCode;
		Trader trader=null;
		
		Client client = getClient();
		
		//Targeting the RESTful Webservice we want to invoke by capturing it in WebTarget instance.
		WebTarget target = client.target(TRADER_SERVICES_URL + traderName);
		
		
		//Building the request i.e a GET request to the RESTful Webservice defined
		//by the URI in the WebTarget instance.
		Invocation getAddrEntryInvocation = target.request(MediaType.APPLICATION_XML_TYPE).buildGet();
		Response response = getAddrEntryInvocation.invoke();
		
		responseCode = response.getStatus();
		logger.info("The response code is: " + responseCode);
		if (responseCode == 200) {
			trader = response.readEntity(Trader.class);
			logger.info(trader);
		}
		
		return trader;
	}
	
	/* Using a POST Http Command, we'll add a completely new student */
	public static void testPost() {
		int responseCode;
		Trader newTrader;
		Client client = getClient();
		
		newTrader = createNewTrader();
		
		WebTarget target = client.target(TRADER_SERVICES_URL);
		
		Builder request = target.request();
		request.accept(MediaType.APPLICATION_XML_TYPE);
		Response response = request.post(Entity.xml(newTrader));
		
		responseCode = response.getStatus();
		logger.info("The response code from Post operation is: " + responseCode);
		
		if (responseCode == 201) {
			Trader createdTrader = response.readEntity(Trader.class);
			logger.debug("Student object returned by the POST command: " + createdTrader);
		}
	}
	
	/* Using a Delete Http Command, we'll delete an existing trader */
	public static void testDelete() {
		int idOfTraderToDelete = 23;  /* just some hardcoded test data */
		int responseCode;
		Client client = getClient();
		
		WebTarget target = client.target(TRADER_SERVICES_URL + idOfTraderToDelete);
		
		Builder request = target.request();
		request.accept(MediaType.APPLICATION_XML_TYPE);
		Response response = request.delete();
		
		responseCode = response.getStatus();
		logger.info("The response code from delete operation is: " + responseCode);
		
		if (responseCode == Status.OK.getStatusCode()) {
			logger.debug("Trader removed");
		}
	}
	
	public static Trader createNewTrader() {
		Trader newTrader;
		
		newTrader = new Trader();
		newTrader.setTraderName("Robert");;
		newTrader.setCompanyName("Apple");
		newTrader.setBuyingUnit(10);
		
		return newTrader;
	}


}
