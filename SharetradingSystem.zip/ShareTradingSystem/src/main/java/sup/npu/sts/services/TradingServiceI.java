package sup.npu.sts.services;

import java.util.ArrayList;
import java.util.List;

import sup.npu.sts.domain.Buyer;
import sup.npu.sts.domain.Company;
import sup.npu.sts.domain.Trader;

public interface TradingServiceI {
	public Trader insertNewTrader(Trader trader);
	public Buyer getBuyerDetailByName(String traderName);
	public Company getCompanyDetailByName(String compName);
	public List<Trader> getTradingList(String traderName);
	public Trader removeTraderWithId(long id);

}
