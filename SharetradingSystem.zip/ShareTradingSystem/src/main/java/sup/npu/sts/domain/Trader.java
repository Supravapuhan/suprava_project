package sup.npu.sts.domain;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "trader")
public class Trader {
	private long id;
	private int traderAccountNo;
	private String traderName;
	private String companyName;
	private int companyId;
	private int buyingUnit;
	private float totalPrice;
	
	

	public int getCompanyId() {
		return companyId;
	}
	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}
	public int getBuyingUnit() {
		return buyingUnit;
	}
	public void setBuyingUnit(int buyingUnit) {
		this.buyingUnit = buyingUnit;
	}
	public float getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	public String toString(){
		return "traderId"+id+"traderAccountNo"+traderAccountNo+"companyId"+companyId+"buyingUnit"+buyingUnit+
				"totalPrice"+totalPrice+"companyName"+companyName+"traderName"+traderName;
	}
	public String getTraderName() {
		return traderName;
	}
	public void setTraderName(String traderName) {
		this.traderName = traderName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public int getTraderAccountNo() {
		return traderAccountNo;
	}
	public void setTraderAccountNo(int traderAccountNo) {
		this.traderAccountNo = traderAccountNo;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public boolean equals(Object tstObj) {
		Trader trader;
		
		if (!(tstObj instanceof Trader)) return false;
		trader = (Trader) tstObj;
		
		if ((trader.id != id) || !(trader.traderName.equals(traderName))) {
			return false;
		}
		
		return true;
	}
	
	
}
