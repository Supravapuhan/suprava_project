package sup.npu.sts.domain;

public class Company {
	
	private int compId;
	private String compSymbol;
	private String compName;
	private int avlUnit;
	private float pricePerUnit;
	
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public String getCompSymbol() {
		return compSymbol;
	}
	public void setCompSymbol(String compSymbol) {
		this.compSymbol = compSymbol;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public int getAvlUnit() {
		return avlUnit;
	}
	public void setAvlUnit(int avlUnit) {
		this.avlUnit = avlUnit;
	}
	public float getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(float pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	

}
