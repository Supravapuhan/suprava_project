package sup.npu.sts.domain;

public class Buyer {
	
	private int traderAccountNo;
	private String traderName;
	private float avlAmount;
	private int phoneNumber;
	
	
	public String getTraderName() {
		return traderName;
	}
	public void setTraderName(String traderName) {
		this.traderName = traderName;
	}
	public float getAvlAmount() {
		return avlAmount;
	}
	public void setAvlAmount(float avlAmount) {
		this.avlAmount = avlAmount;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public int getTraderAccountNo() {
		return traderAccountNo;
	}
	public void setTraderAccountNo(int traderAccountNo) {
		this.traderAccountNo = traderAccountNo;
	}
	

}
