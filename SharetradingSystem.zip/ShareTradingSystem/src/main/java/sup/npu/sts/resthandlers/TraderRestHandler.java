package sup.npu.sts.resthandlers;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import sup.npu.sts.domain.Trader;
import sup.npu.sts.domain.TraderList;
import sup.npu.sts.exceptions.UnknownResourceException;
import sup.npu.sts.services.TradingServiceI;


@Path("/traderestapp")
public class TraderRestHandler {
	@Autowired
	private TradingServiceI traderService;
	private Logger logger = Logger.getLogger(TraderRestHandler.class);
	
	/* Test Url:
	 * http://localhost:8080/tradingapp/webservices/traderestapp/trader/Robert
	 * See web.xml file for Jersey configuration
	 */
	@GET
	@Path("/trader/{traderName}")
	@Produces("application/xml,application/json")
	public Trader getTrader(@PathParam("traderName") String traderName) {
		List<Trader> tradList;
		Trader trader;
		//TraderList listOfTraders = new TraderList();
		
		tradList = traderService.getTradingList(traderName);
			//	listOfTraders.setTraderList(tradList);
		trader=tradList.get(0);
		trader.setTraderName(traderName);
		return trader;		
	}
		

	/* Test Url -- Post the data from file trader.xml (or trader.json) to:
	 *  http://localhost:8080/tradingapp/webservices/traderestapp/trader
	 * After doing the post, use a get command to retrieve the trader (and verify that the post was successful).
	 */
	@POST
	@Path("/trader")
	@Produces("application/json, application/xml")
	@Consumes("application/json, application/xml")
	public Response addTrader(Trader newTrader) {
		logger.info("inside method==="+newTrader.getTraderName());
		ResponseBuilder respBuilder;
		
		traderService.insertNewTrader(newTrader);
		respBuilder = Response.status(Status.CREATED);
		respBuilder.entity(newTrader);
		return respBuilder.build();
	}
	

	/* Test Url -- Put (HTTP Put Command) the data from file student.xml to:
	 * http://localhost:8080/zuniversity/webservices/studrestapp/student/100
	 * After doing the put, use a get command to retrieve the student (and verify that the changes to the original student were made).
	 */
//	@PUT
//	@Path("/buyer/{accnum}")
//	@Produces("application/json, application/xml")
//	@Consumes("application/json, application/xml")
//	public Response updateStudent(@PathParam("accnum") int accnum, Buyer newBuyer) {
//		ResponseBuilder respBuilder;
//		Buyer updatedBuyer;
//		
//		updatedBuyer = traderService.updateBuyer(id, newBuyer);
//		if (updatedStudent == null) {
//			respBuilder = Response.status(Status.NOT_FOUND);
//		} else {
//			respBuilder = Response.status(Status.OK);
//			respBuilder.entity(updatedStudent);
//		}
//		
//		return respBuilder.build();
//	}
	
	/* Test Url:  Use HTTP Delete command
	 * http://localhost:8080/tradingapp/webservices/traderestapp/trader/20
	 */
	@DELETE
	@Path("/trader/{id}")
	public Response deleteStudent(@PathParam("id") int id) {
		Trader removedTrader;
		ResponseBuilder respBuilder;
		
		removedTrader = traderService.removeTraderWithId(id);
		if (removedTrader == null) {
			respBuilder = Response.status(Status.NOT_FOUND);
		} else {
			respBuilder = Response.ok();
			respBuilder.entity(removedTrader);
		}
		return respBuilder.build();
	}
	
	
}
