package sup.npu.sts.dao.jdbc;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import sup.npu.sts.dao.TraderDaoI;
import sup.npu.sts.domain.Buyer;
import sup.npu.sts.domain.Company;
import sup.npu.sts.domain.Trader;


@Repository("traderDaoJdbc")
@Transactional
public class TraderDaoJdbc implements TraderDaoI {
	@Autowired
	@Qualifier("dataSource")
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private NamedParameterJdbcTemplate dbTemplate;
	private SimpleJdbcInsert jdbcInsert;
	private BuyerRowMapper buyerRowMapper;
	private CompanyRowMapper companyRowMapper;
	private TraderRowMapper traderRowMapper;

	@PostConstruct
	public void setup() {
		jdbcTemplate = new JdbcTemplate(dataSource);
		dbTemplate = new NamedParameterJdbcTemplate(dataSource);
		buyerRowMapper=new BuyerRowMapper();
		companyRowMapper=new CompanyRowMapper();
		traderRowMapper=new TraderRowMapper();
		jdbcInsert = new SimpleJdbcInsert(dataSource)
		                 .withTableName("sts_trader_account")
		                 .usingGeneratedKeyColumns("id")
		                 .usingColumns("trader_account_num", "comp_id", "buy_unit", "total_price");
	}

	@Override
	public Trader insertNewTrader(Trader traderFormObj) {		
		 	
		MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("trader_account_num", traderFormObj.getTraderAccountNo());
		params.addValue("comp_id", traderFormObj.getCompanyId());
		params.addValue("buy_unit", traderFormObj.getBuyingUnit());
		params.addValue("total_price", traderFormObj.getTotalPrice());
	    Number newId = jdbcInsert.executeAndReturnKey(params);
	    System.out.println("id returned from database==="+newId);
	    traderFormObj.setId(newId.longValue());	   
		return traderFormObj;
	}
	



	@Override
	public Buyer getBuyerDetailByName(String traderName) {
	     System.out.println("trader Name inside databse "+traderName);

		Buyer buyer ;
		String sqlBuyerDetail ="SELECT trader_account_num,avl_amount from sts_buyer_info WHERE trader_name=:traderName";
		MapSqlParameterSource params = new MapSqlParameterSource("traderName", traderName);
		buyer=dbTemplate.queryForObject(sqlBuyerDetail, params, buyerRowMapper);
       System.out.println("buyer"+buyer.getTraderAccountNo());
		return buyer;
		
}

	@Override
	public Company getCompanyDetailByName(String compName) {
		Company company;
		String sqlCompanyDetail="SELECT comp_id, avl_unit,prc_per_unit from sts_comp_detail WHERE comp_name=:companyName";
		MapSqlParameterSource params = new MapSqlParameterSource("companyName", compName);
		company=dbTemplate.queryForObject(sqlCompanyDetail, params, companyRowMapper);
		return company;
		}

	@Override
	public int updateCompanyAvlUnit(Trader newTrader, Company compObj) {
	
		String updateCompAvlUnitSql="UPDATE sts_comp_detail set avl_unit=:avlUnit WHERE comp_id=:companyId";
		int currAvlUnit,newAvlUnit,unitsPurchaged;
		int compId;		
		int rowsAffected;
		MapSqlParameterSource params;
		
		currAvlUnit=compObj.getAvlUnit();
		unitsPurchaged=newTrader.getBuyingUnit();
		newAvlUnit=currAvlUnit-unitsPurchaged;
		compId=newTrader.getCompanyId();
		
		params = new MapSqlParameterSource();
		params.addValue("avlUnit", newAvlUnit);
		params.addValue("companyId", compId);
		rowsAffected = dbTemplate.update(updateCompAvlUnitSql, params);
		return rowsAffected;

	}

	@Override
	public int updateBuyerAvlAmount(Trader newTrader, Buyer buyerObj) {		
		String updateBuyerAccSql="UPDATE sts_buyer_info set avl_amount=:avlAmount WHERE trader_account_num=:traderAccNum";
		int rowsAffected;
		MapSqlParameterSource params;
		
		int traderAccNum;
		float totalPriceOfUnitPurchaged;
		float currAvlAmount,newAvlAmount;
		traderAccNum=newTrader.getTraderAccountNo();		
		currAvlAmount=buyerObj.getAvlAmount();
		totalPriceOfUnitPurchaged=newTrader.getTotalPrice();
		newAvlAmount=currAvlAmount-totalPriceOfUnitPurchaged;
		
		params = new MapSqlParameterSource();
		params.addValue("avlAmount", newAvlAmount);
		params.addValue("traderAccNum", traderAccNum);
		rowsAffected = dbTemplate.update(updateBuyerAccSql, params);
		return rowsAffected;
		
	}

	@Override
	public List<Trader> getTradingList(String traderName) {
	String sqlgetTradingInfo="SELECT comp.comp_name, SUM(trader.buy_unit) As buy_unit , Sum(trader.total_price) As total_price" +
			" FROM cs532_trading.sts_trader_account trader ,"+
			" cs532_trading.sts_buyer_info buyer,"+
			" cs532_trading.sts_comp_detail comp"+
			" WHERE trader.trader_account_num = buyer.trader_account_num"+
			" and trader.comp_id = comp.comp_id"+
			" and buyer.trader_name = :traderName group by comp.comp_name";

		MapSqlParameterSource params = new MapSqlParameterSource("traderName", traderName);
		List<Trader> traderList = dbTemplate.query(sqlgetTradingInfo, params, traderRowMapper);

		if (traderList.size() == 0) {
			return null;
		}
		return traderList;
	
	}

	@Override
	public Trader removeTraderWithId(long id) {
		Trader trader=new Trader();
		String sqlRemoveTrader="DELETE from cs532_trading.sts_trader_account WHERE id=?";
		int idRet=jdbcTemplate.update(sqlRemoveTrader, id);
		System.out.println("id returned==="+idRet);
		trader.setId(idRet);
		return trader;
	}
	
	


}
