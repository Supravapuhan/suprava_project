package sup.npu.sts.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import sup.npu.sts.domain.Buyer;
import sup.npu.sts.domain.Company;

public class CompanyRowMapper implements RowMapper<Company> {

	public Company mapRow(ResultSet resultSet, int row) throws SQLException {
	int traderAccountNo;
	float avlAmount;
	Company company;
	int compId;
	int avlUnit;
	float pricePerUnit;
	
	
	compId = resultSet.getInt("comp_id");
	avlUnit = resultSet.getInt("avl_unit");
	pricePerUnit=resultSet.getFloat("prc_per_unit");
	
	company = new Company();
	company.setCompId(compId);
	company.setAvlUnit(avlUnit);
	company.setPricePerUnit(pricePerUnit);			
			
	return company;
}

}
