package sup.npu.sts.dao.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import sup.npu.sts.domain.Company;
import sup.npu.sts.domain.Trader;

public class TraderRowMapper implements RowMapper<Trader>{

	@Override
	public Trader mapRow(ResultSet results, int arg1) throws SQLException {

		String companyName;
		int buyingUnit;
		float totalPrice;
		Trader trader;
		
		trader=new Trader();
		trader.setCompanyName(results.getString("comp_name"));
		trader.setBuyingUnit(results.getInt("buy_unit"));
		trader.setTotalPrice(results.getFloat("total_price"));
				
		return trader;

	}

}
