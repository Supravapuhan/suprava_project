package sup.npu.sts.domain;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class TraderList implements Serializable{
	private static final long serialVersionUID = 1L;
	// XmlElement sets the name of the entities
	@XmlElement(name = "trader")
	private List<Trader> tList;

	public TraderList() {
	}
	
	public List<Trader> getTList() {
		return tList;
	}

	public void setTraderList(List<Trader> newTradList) {
		this.tList = newTradList;
	}
	
	public int numEntries() {
		if (tList == null) return 0;
		return tList.size();
	}
	
	public Trader getTrader(int idx) {
		return tList.get(idx);
	}
	
	public String toString() {
		String listStr;
		
		listStr = "TraderList{";
		for (Trader entry: tList) {
			listStr = listStr + "\n\t" + entry;
		}
		
		listStr = listStr + "\n}";
		return listStr;
	}
}
