package sup.npu.sts.dao;

import java.util.ArrayList;
import java.util.List;

import sup.npu.sts.domain.Buyer;
import sup.npu.sts.domain.Company;
import sup.npu.sts.domain.Trader;

public interface TraderDaoI {
	
	public Trader insertNewTrader(Trader traderFormObj);
	public Buyer getBuyerDetailByName(String traderName);
	public Company getCompanyDetailByName(String compName);
	public int updateCompanyAvlUnit(Trader newTrader, Company compObj);
	public int updateBuyerAvlAmount(Trader newTrader,Buyer buyerObj);
	public List<Trader> getTradingList(String traderName);
	public Trader removeTraderWithId(long id);

}
