package sup.npu.sts.tests;

import static org.junit.Assert.assertEquals;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.junit.Before;
import org.junit.Test;

import sup.npu.sts.domain.Trader;


/* 
 * As an exercise, write additional tests for the Put and Delete services.
 */
public class TraderRestTest {
	private static String TRADER_SERVICES_URL = "http://localhost:8080/tradingapp/webservices/traderestapp/trader/";
	private Trader testTrader;
	
	@Before
	public void init() {
		testTrader = new Trader();	
		testTrader.setId(0);
		testTrader.setTraderAccountNo(0);
		testTrader.setTraderName("Robert");
		testTrader.setCompanyName("Apple");
		testTrader.setCompanyId(0);
		testTrader.setBuyingUnit(10);
		testTrader.setTotalPrice(500);
	}
		
	
	/* Client is Required for JAX-RS authorization processing (user name and password must be provided) */
	private  Client getClientWithAuth() {
		Client client;
		
		client = ClientBuilder.newClient();
		/* Dummy user/password that should be overridden in the actual invocations */
		HttpAuthenticationFeature authFeature = HttpAuthenticationFeature.basic("user", "password");
		client.register(authFeature);
		
		return client;
	}

	@Test
	public  void testLookupTrader() {
		String traderName="Robert";  /* Just some hardcoded test data */
		int responseCode;
		Trader trader=null;
		
		Client client = ClientBuilder.newClient();
		
		// Targeting the RESTful Webservice URI we want to invoke by capturing it in WebTarget instance.
		WebTarget target = client.target(TRADER_SERVICES_URL + traderName);
		
		
		//Building the request i.e a GET request to the RESTful Webservice defined
		//by the URI in the WebTarget instance.
		Invocation getTraderInvocation = target.request(MediaType.APPLICATION_XML_TYPE).buildGet();
		Response response = getTraderInvocation.invoke();
		
		responseCode = response.getStatus();
		assertEquals(responseCode, 200);
		
		trader = response.readEntity(Trader.class);
		//System.out.println("trader detail=="+trader.toString());
		//System.out.println("trader detail=="+testTrader.toString());
		assertEquals(trader,testTrader);
	}
	

//	@Test
//	public void testPost() {
//		int responseCode;
//		Trader newTrader = new Trader();
//		newTrader.setTraderName("Robert");;
//		newTrader.setCompanyName("Apple");
//		newTrader.setBuyingUnit(10);
//		
//		
//		Client client = ClientBuilder.newClient();
//		
//		WebTarget target = client.target(TRADER_SERVICES_URL);
//		
//		Builder request = target.request();
//		request.accept(MediaType.APPLICATION_XML_TYPE);
//		Response response = request.post(Entity.xml(newTrader));
//		
//		responseCode = response.getStatus();
//		assertEquals(responseCode, 201);
//		
//		Trader createdTrader = response.readEntity(Trader.class);
//		long createdId = createdTrader.getId();
//		newTrader.setId(createdId);
//		assertEquals(newTrader,createdTrader);
//	}
	
}
