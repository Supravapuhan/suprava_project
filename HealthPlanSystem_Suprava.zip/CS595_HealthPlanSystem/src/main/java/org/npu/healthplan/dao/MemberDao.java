package org.npu.healthplan.dao;

import java.util.List;

import org.npu.healthplan.domain.Member;

public interface MemberDao {
	public void addMember(Member member);
	public List<Member> getMembersBySubscrId(int subscrId);
}
