package org.npu.healthplan.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class EnrollmentPK implements Serializable{	

	/**
	 * 
	 */
	public static final long serialVersionUID = 1L;


	@Column(name = "Member_ID", nullable = false)
	public int Member_ID;
	

	@Column(name = "Subscr_ID", nullable = false)
	public int Subscr_ID;
	

	@Column(name = "Plan_ID", nullable = false)
	public int Plan_ID;
	
	public int getMember_ID() {
		return Member_ID;
	}


	public void setMember_ID(int member_ID) {
		Member_ID = member_ID;
	}


	public int getSubscr_ID() {
		return Subscr_ID;
	}


	public void setSubscr_ID(int subscr_ID) {
		Subscr_ID = subscr_ID;
	}


	public int getPlan_ID() {
		return Plan_ID;
	}


	public void setPlan_ID(int plan_ID) {
		Plan_ID = plan_ID;
	}


	public EnrollmentPK() {
		
	}


	public EnrollmentPK(int member_ID, int subscr_ID, int plan_ID) {
		this.Member_ID = member_ID;
		this.Subscr_ID = subscr_ID;
		this.Plan_ID = plan_ID;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Member_ID;
		result = prime * result + Plan_ID;
		result = prime * result + Subscr_ID;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EnrollmentPK other = (EnrollmentPK) obj;
		if (Member_ID != other.Member_ID)
			return false;
		if (Plan_ID != other.Plan_ID)
			return false;
		if (Subscr_ID != other.Subscr_ID)
			return false;
		return true;
	}

	

}
