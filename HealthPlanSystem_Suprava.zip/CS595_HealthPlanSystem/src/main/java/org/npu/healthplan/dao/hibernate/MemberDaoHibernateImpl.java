package org.npu.healthplan.dao.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.npu.healthplan.dao.MemberDao;
import org.npu.healthplan.domain.Member;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Transactional
@Repository("MemberDaoImpl")
public class MemberDaoHibernateImpl implements MemberDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory){
		this.sessionFactory = sessionFactory ;
	}
	
	
	@Override
	public void addMember(Member member) {
		Session session = sessionFactory.openSession();
		session.saveOrUpdate(member);

	}

	
	@Override
	public List<Member> getMembersBySubscrId(int subscrId) {
		List<Member> memberList;
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from Member where Subscr_ID=:subscrID");
		query.setInteger("subscrID", subscrId);
		memberList = query.list();
		return memberList;
	}

}
