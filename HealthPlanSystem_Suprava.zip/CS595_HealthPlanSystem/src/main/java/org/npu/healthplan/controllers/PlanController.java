package org.npu.healthplan.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.npu.healthplan.domain.Address;
import org.npu.healthplan.domain.Enrollment;
import org.npu.healthplan.domain.EnrollmentPK;
import org.npu.healthplan.domain.Member;
import org.npu.healthplan.domain.MemberPremium;
import org.npu.healthplan.domain.Plan;
import org.npu.healthplan.domain.PremiumRate;
import org.npu.healthplan.domain.Subscriber;
import org.npu.healthplan.services.AddMemberService;
import org.npu.healthplan.services.EnrollPlanService;
import org.npu.healthplan.services.PlanService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class PlanController {
	@Autowired
	PlanService planService;
	@Autowired
	AddMemberService memberService;
	@Autowired
	EnrollPlanService enrollPlanService;
	
	
	private static final Logger logger = LoggerFactory.getLogger(PlanController.class);
	
	// Present the student data form
		@RequestMapping(value = "/enrollNewPlanForm", method = RequestMethod.GET)
		public ModelAndView enrollNewPlanForm(HttpSession session) {
			
			List<Plan> planList=planService.getPlans();			
			
			System.out.println("Plan Name===="+planList.get(0).getPlan_Name());
			ModelAndView modelView;
			modelView = new ModelAndView("PlanForm");
	 		modelView.addObject("plan", new Plan());
	 		modelView.addObject("planList", planList);
	 		session.setAttribute("planlist", planList);
	 		return modelView;
		}
		
		@RequestMapping("/viewPlan")   
		   public ModelAndView viewPlan(){  
		        List<Plan> list =  planService.getPlans();
		        return new ModelAndView("viewPlan","list",list);  
		    }

		
		@RequestMapping(value = "/processEnrollPlan", method = RequestMethod.POST)
		public ModelAndView processNewEnrollPlan(@Valid Plan plan, BindingResult result, HttpSession session) {
			logger.info("Welcome to process new plan controller");
			Enrollment enrollment;
			EnrollmentPK enrollmentPK;
			PremiumRate premiumRate;
			MemberPremium memberPremium;
			ModelAndView modelView;
			int planId = 0;
			int memberCount=0;
			
			if (result.hasErrors()) {
				
				modelView = new ModelAndView("PlanForm");
				return modelView;
			}			
			
			/*
			 * Get subscriber id
			 * Go to member table based on subscriber id
			 * get member id and total number of members count
			 * Insert into enrollment table
			 */
			Subscriber sessionSubscr=(Subscriber) session.getAttribute("subscriber");
			System.out.println("plan name===="+plan.getPlan_Name());
			
			enrollmentPK=new EnrollmentPK();
			enrollment=new Enrollment();
			
			List<Plan> planList=(List<Plan>) session.getAttribute("planlist");
			for(int i=0;i<planList.size();i++){
				Plan newPlan=planList.get(i);
				if(newPlan.getPlan_Name().equals(plan.getPlan_Name())){
					planId=newPlan.getPlan_ID();
					enrollment.setEnrl_Eff_Date(newPlan.getPlan_Eff_Date());
					enrollment.setEnrl_Term_Date(newPlan.getPlan_Term_Date());
					break;
				}
			}
			
			System.out.println("plan id===="+planId);
			System.out.println("subscr id in enrollplan===="+sessionSubscr.getSubscr_ID());
			
			List<Member> memberList=memberService.getMembersBySubscrId(sessionSubscr.getSubscr_ID());
			memberCount=memberList.size();
			int memeberID=memberList.get(0).getMember_ID();
			int subscrID=sessionSubscr.getSubscr_ID();
			
			enrollmentPK.setMember_ID(memeberID);
			enrollmentPK.setPlan_ID(planId);
			enrollmentPK.setSubscr_ID(subscrID);
			enrollment.setEnrollmentPK(enrollmentPK);
			
//			String lastCrawlDate = "2017-01-30";
//			Date utilDate = null;
//			try {
//				utilDate = new SimpleDateFormat("yyyy-MM-dd").parse(lastCrawlDate);
//			} catch (ParseException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			// because PreparedStatement#setDate(..) expects a java.sql.Date argument
//			java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime()); 
//
//			enrollment.setEnrl_Eff_Date(sqlDate);
//			enrollment.setEnrl_Term_Date(sqlDate);
			
			System.out.println("before inserting===="+enrollmentPK.getMember_ID()+""+enrollmentPK.getPlan_ID()+""+enrollmentPK.getSubscr_ID());
			System.out.println("before inserting===="+enrollment.getEnrl_Eff_Date());
			
			enrollPlanService.enrollToPlan(enrollment);
			
			/*
			 * now go to Premium rate table based on Plan id and member count 
			 * get the rate-indx and rate
			 * Insert member_prem table
			 */
			
			System.out.println("member count===="+memberCount);
			
			List<PremiumRate> premimumList=enrollPlanService.getPremiumRate(planId, memberCount);
			premiumRate=premimumList.get(0);
			System.out.println("rate indx===="+premiumRate.getRate_Indx());
			System.out.println("plan id===="+premiumRate.getPlan_ID());
			System.out.println("member cov===="+premiumRate.getMember_Cov());
			System.out.println("prm rate===="+premiumRate.getPlan_Prm_Rate());
			memberPremium=new MemberPremium();
			memberPremium.setSubscr_ID(subscrID);
			memberPremium.setMember_Count(memberCount);
			memberPremium.setTotal_Premium(premiumRate.getPlan_Prm_Rate());
			memberPremium.setRate_Indx(premiumRate.getRate_Indx());
			enrollPlanService.addMemberPremium(memberPremium);
			
			modelView=new ModelAndView("EnrollPlanSuccess");
			modelView.addObject("enrollment",enrollment);
			modelView.addObject("subscrName", sessionSubscr.getFirst_name());
			modelView.addObject("planName", plan.getPlan_Name());
			modelView.addObject("memberpremium",memberPremium);			
			return modelView;
			
			
		}

}
