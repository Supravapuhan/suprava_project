package org.npu.healthplan.dao;

import org.npu.healthplan.domain.Address;

public interface AddressDao {
	public Address saveAddress(Address address);

}
