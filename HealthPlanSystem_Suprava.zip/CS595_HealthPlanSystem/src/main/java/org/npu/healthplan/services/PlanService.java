package org.npu.healthplan.services;
import java.util.List;

import org.npu.healthplan.domain.Plan;


public interface PlanService {

	public List<Plan> getPlans();
}
