package org.npu.healthplan.dao;

import java.util.List;

import org.npu.healthplan.domain.Plan;

public interface PlanDao {
	public List<Plan> getPlans();

}
