package org.npu.healthplan.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.npu.healthplan.domain.Address;
import org.npu.healthplan.domain.Member;
import org.npu.healthplan.domain.Subscriber;
import org.npu.healthplan.services.AddMemberService;
import org.npu.healthplan.services.AddressService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MemberController {

	@Autowired
	AddMemberService memberService;
	
	@Autowired
	private AddressService addressService;
	
	
	
	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);
	
	// Present the student data form
	@RequestMapping(value = "/newMemberDataForm", method = RequestMethod.GET)
	public ModelAndView newMemberDataForm(HttpSession session) {
		
		System.out.println("welcome to member====");
		ModelAndView modelView;
		session.setAttribute("form", "memberForm");
 		modelView = new ModelAndView("memberDataForm");
 		modelView.addObject("member", new Member());
 		Member memberdata=(Member) modelView.getModel().get("member");
 		memberdata.setEnumAddress("Yes");
 		session.setAttribute("prevmember", memberdata);
 		Member retmember=(Member) session.getAttribute("prevmember");
 		System.out.println("enumadd===="+retmember.getEnumAddress());
		return modelView;
	}

	@RequestMapping(value = "/processNewMemberProfile", method = RequestMethod.POST)
	public ModelAndView processNewMemberProfile(@ModelAttribute("member") @Valid Member member, BindingResult result, HttpSession session) {
		logger.info("Welcome to add member controller");
		ModelAndView modelView;
		Address retAddress;
		
				
		Address subscrAddress=(Address) session.getAttribute("subscrAddress");
		Subscriber sessionSubscr=(Subscriber) session.getAttribute("subscriber");
			
		if (result.hasErrors()) {
			/*  Re-present the form with error messages */
			modelView = new ModelAndView("memberDataForm");
			return modelView;
		}
		
		
		member.setSubscr_ID(sessionSubscr.getSubscr_ID());
		System.out.println(member.getSubscr_ID());
		System.out.println(member.getLast_Name());
		System.out.println(member.getFirst_Name());
		System.out.println(member.getGender());
		System.out.println(member.getBirth_Date());
		 
//		if(member.getGender().equals("Male")){
//			member.setSuffix("S");
//		}else if(member.getGender().equals("Female")){
//			
//			member.setSuffix("D");
//		}else{
//			member.setSuffix("O");
//		}
		
		if(member.getSuffix().equals("Spouse")){
			member.setSuffix("SP");
		}else if(member.getSuffix().equals("Son")){			
			member.setSuffix("S");
		}else if(member.getSuffix().equals("Daughter")){			
			member.setSuffix("D");
		}else{
			member.setSuffix("O");
		}
		
		if(member.getEnumAddress().equals("Yes")){
			member.setAddress_SFX(subscrAddress.getAddress_SFX());
		}else{
			
			//add address first
			Address sessionaddress=(Address) session.getAttribute("address");
			
			System.out.println("sessionaddress"+sessionaddress.getAddress_1());
			System.out.println("sessionaddress"+sessionaddress.getAddress_2());
			System.out.println("sessionaddress"+sessionaddress.getCity());
			System.out.println("sessionaddress"+sessionaddress.getState());
			System.out.println("sessionaddress"+sessionaddress.getZip());
			
			sessionaddress.setSubscr_ID(sessionSubscr.getSubscr_ID());
			System.out.println("addrss subscr id"+sessionaddress.getSubscr_ID());
			
		
			retAddress=addressService.saveAddress(sessionaddress);
			member.setAddress_SFX(retAddress.getAddress_SFX());
		}
		
		memberService.addMember(member);
 		modelView = new ModelAndView("addSubscriberSuccess");
 		session.setAttribute("member", member);
 		modelView.addObject("member", member);
 		
 		return modelView;
	}
	
	
	@RequestMapping(value = "/prevMemberDataForm", method = RequestMethod.GET)
	public ModelAndView prevMemberDataForm(HttpSession session) {
		
		System.out.println("welcome to preveius member form====");
		ModelAndView modelView;
		modelView = new ModelAndView("memberDataForm");
		Member retmember=(Member) session.getAttribute("prevmember");
		retmember.setEnumAddress("No");
 		modelView.addObject("member", retmember);
 		session.setAttribute("prevmember", retmember); 		
		return modelView;
	}	
	
}
