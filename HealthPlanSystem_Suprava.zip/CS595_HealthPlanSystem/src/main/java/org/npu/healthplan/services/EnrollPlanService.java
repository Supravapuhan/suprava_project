package org.npu.healthplan.services;

import java.util.List;

import org.npu.healthplan.domain.Enrollment;
import org.npu.healthplan.domain.Member;
import org.npu.healthplan.domain.MemberPremium;
import org.npu.healthplan.domain.PremiumRate;

public interface EnrollPlanService {
	public void enrollToPlan(Enrollment enrollment);
	public List<PremiumRate> getPremiumRate(int planID,int memberCount);
	public void addMemberPremium(MemberPremium memberPremium);
}
