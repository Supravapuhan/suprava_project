package org.npu.healthplan.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="premium_rate")
public class PremiumRate {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Rate_Indx;
	
	@Column(name = "Plan_ID", nullable = false)
	private int Plan_ID;
	
	@Column(name = "Member_Cov", nullable = false)
	private int Member_Cov;
	
	@Column(name = "Plan_Prm_Rate", nullable = false)
	private Double Plan_Prm_Rate;

	public int getRate_Indx() {
		return Rate_Indx;
	}

	public void setRate_Indx(int rate_Indx) {
		Rate_Indx = rate_Indx;
	}

	public int getPlan_ID() {
		return Plan_ID;
	}

	public void setPlan_ID(int plan_ID) {
		Plan_ID = plan_ID;
	}

	public int getMember_Cov() {
		return Member_Cov;
	}

	public void setMember_Cov(int member_Cov) {
		Member_Cov = member_Cov;
	}

	public Double getPlan_Prm_Rate() {
		return Plan_Prm_Rate;
	}

	public void setPlan_Prm_Rate(Double plan_Prm_Rate) {
		Plan_Prm_Rate = plan_Prm_Rate;
	}
	
}
