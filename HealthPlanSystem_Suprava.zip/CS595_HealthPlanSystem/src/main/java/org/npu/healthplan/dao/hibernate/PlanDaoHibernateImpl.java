package org.npu.healthplan.dao.hibernate;

import java.util.List;

import org.hibernate.SessionFactory;
import org.npu.healthplan.dao.PlanDao;
import org.npu.healthplan.domain.Plan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.Session;
import org.hibernate.Query;
@Transactional
@Repository("PlanDaoImpl")
public class PlanDaoHibernateImpl implements PlanDao {

	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFsctory(SessionFactory sessionFactory){
		this.sessionFactory = sessionFactory ;
	}
	
	@Override
	public List<Plan> getPlans() {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from Plan");
		return query.list();
	}

}
