package org.npu.healthplan.dao.hibernate;

import java.util.Random;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.npu.healthplan.dao.AddressDao;
import org.npu.healthplan.domain.Address;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Repository("AddressDaoImpl")
public class AddressDaoHibernateImpl implements AddressDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFsctory(SessionFactory sessionFactory){
		this.sessionFactory = sessionFactory ;
	}
	
	@Override
	public Address saveAddress(Address address){
		
		Session session = sessionFactory.openSession();
		session.saveOrUpdate(address);
		return address;
		
				
	}

	

	String CHAR_LIST="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	public String generateRandomString(){
	   
        StringBuffer randStr = new StringBuffer();
        for(int i=0; i<3; i++){
            int number = getRandomNumber();
            char ch = CHAR_LIST.charAt(number);
            randStr.append(ch);
        }
        return randStr.toString();
    }
     
    /**
     * This method generates random numbers
     * @return int
     */
    private int getRandomNumber() {
        int randomInt = 0;
        Random randomGenerator = new Random();
        randomInt = randomGenerator.nextInt(CHAR_LIST.length());
        if (randomInt - 1 == -1) {
            return randomInt;
        } else {
            return randomInt - 1;
        }
    }
}
