package org.npu.healthplan.services;

import java.util.List;

import org.npu.healthplan.dao.PlanDao;
import org.npu.healthplan.domain.Plan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class PlanServiceImpl implements PlanService {
		
	@Autowired
	@Qualifier("PlanDaoImpl")
	private PlanDao planDao;
	
	@Override
	public List<Plan> getPlans() {
		// TODO Auto-generated method stub
		return planDao.getPlans();
	}

}
