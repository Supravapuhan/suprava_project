package org.npu.healthplan.domain;

import java.util.Random;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;


@Entity
@Table(name="address")
@XmlRootElement(name = "address")
public class Address {
	
	@Column(name = "Subscr_ID", nullable = false)
	private int Subscr_ID;
		
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Address_SFX;
	
	
	@NotEmpty
	@Column(name = "Address_1", nullable = false)
	private String Address_1;
	
	@NotEmpty
	@Column(name = "Address_2", nullable = false)
	private String Address_2;
	
	@NotEmpty
	@Column(name = "State", nullable = false)
	private String State;
	
	@NotEmpty
	@Column(name = "City", nullable = false)
	private String City;
	
	@Column(name = "Zip", nullable = false)
	@NotNull
	private int Zip;
	

	
	public int getSubscr_ID() {
		return Subscr_ID;
	}
	public void setSubscr_ID(int subscr_ID) {
		Subscr_ID = subscr_ID;
	}
	
	public int getAddress_SFX() {
		return Address_SFX;
	}
	public void setAddress_SFX(int address_SFX) {
		Address_SFX = address_SFX;
	}
	public String getAddress_1() {
		return Address_1;
	}
	public void setAddress_1(String address_1) {
		Address_1 = address_1;
	}
	public String getAddress_2() {
		return Address_2;
	}
	public void setAddress_2(String address_2) {
		Address_2 = address_2;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public int getZip() {
		return Zip;
	}
	public void setZip(int zip) {
		Zip = zip;
	}
	
}
