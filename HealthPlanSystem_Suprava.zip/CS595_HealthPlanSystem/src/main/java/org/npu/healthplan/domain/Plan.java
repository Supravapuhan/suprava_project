package org.npu.healthplan.domain;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

@XmlRootElement(name ="plan")
@Entity
@Table(name="plan")
public class Plan {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Plan_ID;
	
	@Column(name = "Plan_Name", nullable = false)
	private String Plan_Name;
	
	@Column(name = "Plan_Eff_Date", nullable = false)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date Plan_Eff_Date;
	
	
	@Column(name = "Plan_Term_Date", nullable = false)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date Plan_Term_Date;
	
	@Column(name = "Description", nullable = false)
	private String Description;
	
	@Column(name = "Price", nullable = false)
	private int Price;
	
	
	
	public Plan() {
		super();
	}
	
	

	public Plan(String plan_Name) {
		this.Plan_Name = plan_Name;		
	}
	
	
	public int getPlan_ID() {
		return Plan_ID;
	}

	public void setPlan_ID(int plan_ID) {
		Plan_ID = plan_ID;
	}

	public String getPlan_Name() {
		return Plan_Name;
	}

	public void setPlan_Name(String plan_Name) {
		Plan_Name = plan_Name;
	}

	public Date getPlan_Eff_Date() {
		return Plan_Eff_Date;
	}

	public void setPlan_Eff_Date(Date plan_Eff_Date) {
		Plan_Eff_Date = plan_Eff_Date;
	}

	public Date getPlan_Term_Date() {
		return Plan_Term_Date;
	}

	public void setPlan_Term_Date(Date plan_Term_Date) {
		Plan_Term_Date = plan_Term_Date;
	}
	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public int getPrice() {
		return Price;
	}

	public void setPrice(int price) {
		Price = price;
	}
	
}
