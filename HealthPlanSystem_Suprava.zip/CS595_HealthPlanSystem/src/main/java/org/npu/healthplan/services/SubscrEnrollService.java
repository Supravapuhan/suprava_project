package org.npu.healthplan.services;

import org.npu.healthplan.domain.Subscriber;

public interface SubscrEnrollService {
	public Subscriber addSubscriber(Subscriber subscriber);
	
}
