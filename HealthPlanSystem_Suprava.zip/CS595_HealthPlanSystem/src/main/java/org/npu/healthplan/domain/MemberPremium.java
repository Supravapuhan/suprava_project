package org.npu.healthplan.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "memberpremium")
@Entity
@Table(name="member_premium")
public class MemberPremium {
	@Id
	@Column(name = "Subscr_ID", nullable = false)
	private int Subscr_ID;
		
	@Column(name = "Member_Count", nullable = false)
	private int Member_Count;
	
	@Column(name = "Total_Premium", nullable = false)
	private Double Total_Premium;
	
	@Column(name = "Rate_Indx", nullable = false)
	private int Rate_Indx;

	public int getSubscr_ID() {
		return Subscr_ID;
	}

	public void setSubscr_ID(int subscr_ID) {
		this.Subscr_ID = subscr_ID;
	}

	public int getMember_Count() {
		return Member_Count;
	}

	public void setMember_Count(int member_Count) {
		this.Member_Count = member_Count;
	}

	public Double getTotal_Premium() {
		return Total_Premium;
	}

	public void setTotal_Premium(Double total_Premium) {
		this.Total_Premium = total_Premium;
	}

	public int getRate_Indx() {
		return Rate_Indx;
	}

	public void setRate_Indx(int rate_Indx) {
		this.Rate_Indx = rate_Indx;
	}
	
}
