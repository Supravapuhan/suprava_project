package org.npu.healthplan.dao.hibernate;

import org.npu.healthplan.dao.SubscriberDao;
import org.npu.healthplan.domain.Subscriber;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Repository("SubscriberDaoImpl")
public class SubscriberDaoHibernateImpl implements SubscriberDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFsctory(SessionFactory sessionFactory){
		this.sessionFactory = sessionFactory ;
	}
	
	@Override
	public Subscriber saveSubscriber(Subscriber subscriber){
		
		Session session = sessionFactory.openSession();
		session.saveOrUpdate(subscriber);
		System.out.println("after save : subscr id's = "+subscriber.getSubscr_ID());
		return subscriber;

	}



}
