package org.npu.healthplan.services;

import org.npu.healthplan.dao.SubscriberDao;
import org.npu.healthplan.domain.Subscriber;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class SubscrEnrollServiceImpl implements SubscrEnrollService {
	@Autowired
	@Qualifier("SubscriberDaoImpl")
	private SubscriberDao subscriberDao;

	@Override
	public Subscriber addSubscriber(Subscriber subscriber) {
		Subscriber retSubscriber=subscriberDao.saveSubscriber(subscriber);
		return retSubscriber;
		
	}
	
	
}
