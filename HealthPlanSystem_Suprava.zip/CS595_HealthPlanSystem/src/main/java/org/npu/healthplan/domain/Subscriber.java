package org.npu.healthplan.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name="subscriber")
@XmlRootElement(name = "subscriber")
public class Subscriber {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Subscr_ID;
	
	@Column(name = "First_name", nullable = false)
	@Size(min=2, max=30)
	private String First_name;
	
	@Column(name = "Last_Name", nullable = false)
	@Size(min=2, max=30)
	private String Last_Name;
	
	
	@Column(name = "Gender", nullable = false)
	private String Gender;
	
	@Column(name = "Birth_Date", nullable = false)
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date Birth_Date;
	
	public  Subscriber(){}

	public int getSubscr_ID() {
		return Subscr_ID;
	}

	public void setSubscr_ID(int subscr_ID) {
		Subscr_ID = subscr_ID;
	}

	public String getFirst_name() {
		return First_name;
	}

	public void setFirst_name(String first_name) {
		First_name = first_name;
	}

	public String getLast_Name() {
		return Last_Name;
	}

	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}

	
	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	
	public Date getBirth_Date() {
		return Birth_Date;
	}

	public void setBirth_Date(Date birth_Date) {
		Birth_Date = birth_Date;
	}
	
	
}
