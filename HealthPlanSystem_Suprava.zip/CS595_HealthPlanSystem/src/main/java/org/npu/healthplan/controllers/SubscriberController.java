package org.npu.healthplan.controllers;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.npu.healthplan.domain.Address;
import org.npu.healthplan.domain.Member;
import org.npu.healthplan.domain.Subscriber;
import org.npu.healthplan.services.AddMemberService;
import org.npu.healthplan.services.AddressService;
import org.npu.healthplan.services.SubscrEnrollService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;


@Controller
public class SubscriberController {
	
	
	@Autowired
	private SubscrEnrollService subscriberService;
	
	@Autowired
	private AddressService addressService;
	
	@Autowired
	private AddMemberService memberService;
	

private static final Logger logger = LoggerFactory.getLogger(SubscriberController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
@RequestMapping(value = "/subscriberForm", method = RequestMethod.GET)
public ModelAndView subscriberForm(HttpSession session) {
	ModelAndView modelView;
	session.setAttribute("form", "subscrForm");
	
	modelView = new ModelAndView("subscriberForm");
	modelView.addObject("subscriber", new Subscriber());
	
	return modelView;

}


@RequestMapping(value = "/addressForm", method = RequestMethod.GET)
public ModelAndView addressForm() {
		ModelAndView modelView;
		
		modelView = new ModelAndView("addressForm");
		modelView.addObject("address", new Address());
		return modelView;
}




@RequestMapping(value = "/saveSubscriber", method = RequestMethod.POST)
public ModelAndView saveSubscriber(@Valid Subscriber subscriber, BindingResult result,HttpSession session) {
	logger.info("Welcome to save subscriber controller");
	ModelAndView modelView;
	
	Subscriber retSubscriber=new Subscriber() ;
	Address retAddress;
	Address sessionaddress=(Address) session.getAttribute("address");
	System.out.println("sessionaddress"+sessionaddress.getAddress_1());
	System.out.println("sessionaddress"+sessionaddress.getAddress_2());
	System.out.println("sessionaddress"+sessionaddress.getCity());
	System.out.println("sessionaddress"+sessionaddress.getState());
	System.out.println("sessionaddress"+sessionaddress.getZip());
		
	Member member=new Member();
	
	
	if (result.hasErrors()) {
		
		modelView = new ModelAndView("subscriberForm");
		return modelView;
	}	

//	System.out.println(subscriber.getLast_Name());
//	System.out.println(subscriber.getGender());
//	System.out.println(subscriber.getBirth_Date());
//	System.out.println(subscriber.getFirst_name());
	
	retSubscriber=subscriberService.addSubscriber(subscriber);
	sessionaddress.setSubscr_ID(retSubscriber.getSubscr_ID());
	System.out.println("addrss subscr id"+sessionaddress.getSubscr_ID());
		
	retAddress=addressService.saveAddress(sessionaddress);
	
	member.setFirst_Name(retSubscriber.getFirst_name());
	member.setLast_Name(retSubscriber.getLast_Name());
	member.setGender(retSubscriber.getGender());
	member.setBirth_Date(retSubscriber.getBirth_Date());
	member.setSubscr_ID(retSubscriber.getSubscr_ID());
	member.setAddress_SFX(sessionaddress.getAddress_SFX());
	member.setSuffix("M");
	
	memberService.addMember(member);
	
	modelView = new ModelAndView("addSubscriberSuccess");
	session.setAttribute("subscriber",retSubscriber);
	session.setAttribute("subscrAddress",retAddress);
	modelView.addObject("subscriber", retSubscriber);
	return modelView;
}


@RequestMapping(value = "/prevSubscriberForm", method = RequestMethod.POST)
public ModelAndView prevSubscriberForm() {
	logger.info("Welcome to preveious subscriber page");
	ModelAndView modelView;	
	modelView = new ModelAndView("subscriberForm");
	modelView.addObject("subscriber", new Subscriber());
	return modelView;
}

@RequestMapping(value = "/saveAddress", method = RequestMethod.POST)
public ModelAndView saveAddress(@ModelAttribute("address") @Valid Address address, BindingResult result,HttpSession session) {
	logger.info("Welcome to save address controller");
	ModelAndView modelView;
//	System.out.println("address1"+address.getAddress_1());
//	System.out.println("address2"+address.getAddress_2());
//	System.out.println("city"+address.getCity());
//	System.out.println("state"+address.getState());
//	System.out.println("zip"+address.getZip());

	String strForm=(String) session.getAttribute("form");
	System.out.println("formName===="+strForm);
	
	if(strForm.equals("subscrForm")){
		
		modelView = new ModelAndView("redirect:/subscriberForm");
	}else{		
		modelView = new ModelAndView("redirect:/prevMemberDataForm");
		//modelView.addObject("Nchecked", "true");		
	}
		
	session.setAttribute("address",address);
	return modelView;
}

}
