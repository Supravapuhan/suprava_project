package org.npu.healthplan.services;

import java.util.List;

import org.npu.healthplan.domain.Member;



public interface AddMemberService {
	public void addMember(Member member);
	public List<Member> getMembersBySubscrId(int subscrId);

}
