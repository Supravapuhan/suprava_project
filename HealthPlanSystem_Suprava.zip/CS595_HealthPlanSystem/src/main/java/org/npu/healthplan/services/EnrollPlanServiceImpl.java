package org.npu.healthplan.services;

import java.util.List;

import org.npu.healthplan.dao.EnrollPlanDao;
import org.npu.healthplan.domain.Enrollment;
import org.npu.healthplan.domain.MemberPremium;
import org.npu.healthplan.domain.PremiumRate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class EnrollPlanServiceImpl implements EnrollPlanService {
	
	@Autowired
	@Qualifier("EnrollPlanDaoImpl")
	private EnrollPlanDao enrollPlanDao;
	
	@Override
	public void enrollToPlan(Enrollment enrollment) {
		enrollPlanDao.enrollToPlan(enrollment);
	}

	@Override
	public List<PremiumRate> getPremiumRate(int planID, int memberCount) {
		return enrollPlanDao.getPremiumRate(planID, memberCount);
	}

	@Override
	public void addMemberPremium(MemberPremium memberPremium) {
		enrollPlanDao.addMemberPremium(memberPremium);
		
	}

}
