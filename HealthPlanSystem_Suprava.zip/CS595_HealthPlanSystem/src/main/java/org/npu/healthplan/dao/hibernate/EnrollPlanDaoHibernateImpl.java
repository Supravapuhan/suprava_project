package org.npu.healthplan.dao.hibernate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.npu.healthplan.dao.EnrollPlanDao;
import org.npu.healthplan.domain.Enrollment;
import org.npu.healthplan.domain.MemberPremium;
import org.npu.healthplan.domain.PremiumRate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Repository("EnrollPlanDaoImpl")
public class EnrollPlanDaoHibernateImpl implements EnrollPlanDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory){
		this.sessionFactory = sessionFactory ;
	}

	@Override
	public void enrollToPlan(Enrollment enrollment) {		
		Session session = sessionFactory.getCurrentSession();
		session.save(enrollment);

	}

	@Override
	public List<PremiumRate> getPremiumRate(int planID, int memberCount) {
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from PremiumRate where Plan_ID=:planID and Member_Cov=:memberCov");
		query.setInteger("planID", planID);
		query.setInteger("memberCov", memberCount);
		return query.list();
	}

	@Override
	public void addMemberPremium(MemberPremium memberPremium) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(memberPremium);
	}

}
