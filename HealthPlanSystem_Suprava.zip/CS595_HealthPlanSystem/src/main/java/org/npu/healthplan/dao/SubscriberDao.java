package org.npu.healthplan.dao;

import org.npu.healthplan.domain.Subscriber;

public interface SubscriberDao {
public Subscriber saveSubscriber(Subscriber subscriber);
}
