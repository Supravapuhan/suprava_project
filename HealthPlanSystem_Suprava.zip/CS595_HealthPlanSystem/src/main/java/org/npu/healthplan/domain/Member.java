package org.npu.healthplan.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;



@XmlRootElement(name = "member")
@Entity
@Table(name="member")
public class Member {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Member_ID;
		
	@Column(name = "Subscr_ID", nullable = false)
	private int Subscr_ID;
	
	@Column(name = "Address_SFX", nullable = false)
	private int Address_SFX;
	
	@Column(name = "First_Name", nullable = false)
	@Size(min=2, max=30)
	private String First_Name;
	
	@Column(name = "Last_Name", nullable = false)
	@Size(min=2, max=30)
	private String Last_Name;
	
	@Column(name = "Gender", nullable = false)
	private String Gender;
	
	@Column(name = "Birth_Date", nullable = false)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date Birth_Date;
	
	@Column(name = "Suffix", nullable = false)
	private String Suffix;
	
	
	@Transient
	private String enumAddress;
		
	

	public Member() {
	}
	
	public Member(String lastName, String firstName) {
		this.Last_Name = lastName;
		this.First_Name = firstName;
	}
	;
	
	
	
	public String toString() {
		String memberStr = "Member[" + First_Name + " " + Last_Name + "  gender: " + "]";
		return memberStr;
	}
	
	

	public int getMember_ID() {
		return Member_ID;
	}

	public void setMember_ID(int member_ID) {
		Member_ID = member_ID;
	}

	public int getSubscr_ID() {
		return Subscr_ID;
	}

	public void setSubscr_ID(int subscr_ID) {
		Subscr_ID = subscr_ID;
	}

	public String getFirst_Name() {
		return First_Name;
	}

	public void setFirst_Name(String first_Name) {
		First_Name = first_Name;
	}

	
	public String getLast_Name() {
		return Last_Name;
	}

	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public Date getBirth_Date() {
		return Birth_Date;
	}

	public void setBirth_Date(Date birth_Date) {
		Birth_Date = birth_Date;
	}

	public String getSuffix() {
		return Suffix;
	}

	public void setSuffix(String suffix) {
		Suffix = suffix;
	}
	
	
	public int getAddress_SFX() {
		return Address_SFX;
	}

	public void setAddress_SFX(int address_SFX) {
		Address_SFX = address_SFX;
	}
	
	@Transient
	public String getEnumAddress() {
		return enumAddress;
	}

	public void setEnumAddress(String enumAddress) {
		this.enumAddress = enumAddress;
	}

	public boolean equals(Object otherObj) {
		Member otherMember;
		
		if (!(otherObj instanceof Member)) return false;
		otherMember = (Member) otherObj;
		return (Member_ID == otherMember.Member_ID && Last_Name.equals(otherMember.Last_Name) && First_Name.equals(otherMember.First_Name));
	}

}
