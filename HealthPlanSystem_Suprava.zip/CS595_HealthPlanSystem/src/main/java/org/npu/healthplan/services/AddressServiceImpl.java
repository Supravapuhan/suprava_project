package org.npu.healthplan.services;

import org.npu.healthplan.dao.AddressDao;
import org.npu.healthplan.domain.Address;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class AddressServiceImpl implements AddressService{
	@Autowired
	@Qualifier("AddressDaoImpl")
	private AddressDao addressDao;

	@Override
	public Address saveAddress(Address address) {		
		Address retAddress=addressDao.saveAddress(address);
		return retAddress;
	}

}
