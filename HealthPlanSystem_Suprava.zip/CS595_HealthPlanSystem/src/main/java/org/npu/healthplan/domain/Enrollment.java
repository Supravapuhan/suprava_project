package org.npu.healthplan.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.format.annotation.DateTimeFormat;

@XmlRootElement(name = "enrollment")
@Entity
@Table(name="enrollment")
public class Enrollment implements Serializable{
	
   @EmbeddedId
   public  EnrollmentPK enrollmentPK;

//	@Column(name = "Member_ID", nullable = false)
//	private int Member_ID;
//	
//	
//	@Column(name = "Subscr_ID", nullable = false)
//	private int Subscr_ID;
//	
//	
//	@Column(name = "Plan_ID", nullable = false)
//	private int Plan_ID;
	
	
	@Column(name = "Enrl_Eff_Date", nullable = false)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date Enrl_Eff_Date;
	
	
	@Column(name = "Enrl_Term_Date", nullable = false)
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date Enrl_Term_Date;

	
//	public int getMember_ID() {
//		return Member_ID;
//	}
//
//
//	public void setMember_ID(int member_ID) {
//		Member_ID = member_ID;
//	}
//
//
//	public int getSubscr_ID() {
//		return Subscr_ID;
//	}
//
//
//	public void setSubscr_ID(int subscr_ID) {
//		Subscr_ID = subscr_ID;
//	}
//
//
//	public int getPlan_ID() {
//		return Plan_ID;
//	}
//
//
//	public void setPlan_ID(int plan_ID) {
//		Plan_ID = plan_ID;
//	}
//

	public Date getEnrl_Eff_Date() {
		return Enrl_Eff_Date;
	}
	

	public void setEnrl_Eff_Date(Date enrl_Eff_Date) {
		Enrl_Eff_Date = enrl_Eff_Date;
	}


	public Date getEnrl_Term_Date() {
		return Enrl_Term_Date;
	}


	public void setEnrl_Term_Date(Date enrl_Term_Date) {
		Enrl_Term_Date = enrl_Term_Date;
	}
	
	
	public EnrollmentPK getEnrollmentPK() {
		return enrollmentPK;
	}


	public void setEnrollmentPK(EnrollmentPK enrollmentPK) {
		this.enrollmentPK = enrollmentPK;
	}

}
