package org.npu.healthplan.services;

import org.npu.healthplan.domain.Address;

public interface AddressService {	
	public Address saveAddress(Address address);

}
