package org.npu.healthplan.services;

import java.util.List;

import org.npu.healthplan.dao.MemberDao;
import org.npu.healthplan.domain.Member;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service
public class AddMemberServiceImpl implements AddMemberService {

	
	@Autowired
	@Qualifier("MemberDaoImpl")
	private MemberDao memberrDao;

	@Override
	public void addMember(Member member) {		
		memberrDao.addMember(member);
	}

	@Override
	public List<Member> getMembersBySubscrId(int subscrId) {
		// TODO Auto-generated method stub
		return memberrDao.getMembersBySubscrId(subscrId);
	}

	

}
