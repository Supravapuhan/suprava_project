DROP SCHEMA IF EXISTS `cs595_healthplandb`; 
CREATE SCHEMA `cs595_healthplandb` ;
use `cs595_healthplandb`;

CREATE TABLE `cs595_healthplandb`.`subscriber` (
  `Subscr_ID` INT NOT NULL AUTO_INCREMENT,
  `First_name` VARCHAR(45) NOT NULL,
  `Last_Name` VARCHAR(45) NOT NULL,
  `Gender` VARCHAR(10) NOT NULL,
  `Birth_Date` DATE NOT NULL,
  PRIMARY KEY (`Subscr_ID`));

CREATE TABLE `cs595_healthplandb`.`member` (
  `Member_ID` INT NOT NULL,
  `Subscr_ID` INT NOT NULL,
  `First_Name` VARCHAR(45) NOT NULL,
  `Last_Name` VARCHAR(45) NOT NULL,
  `Gender` VARCHAR(10) NOT NULL,
  `Birth_Date` DATE NOT NULL,
  `Suffix` VARCHAR(3) NOT NULL,
  `Address_SFX` VARCHAR(3) NOT NULL,
  PRIMARY KEY (`Member_ID`),
  UNIQUE INDEX `Member_ID_UNIQUE` (`Member_ID` ASC));

CREATE TABLE `cs595_healthplandb`.`plan` (
  `Plan_ID` INT NOT NULL,
  `Plan_Type` VARCHAR(20) NOT NULL,
  `Plan_Eff_Date` DATE NOT NULL,
  `Plan_Term_Date` DATE NOT NULL,
  PRIMARY KEY (`Plan_ID`),
  UNIQUE INDEX `Plan_Type_UNIQUE` (`Plan_ID` ASC));

CREATE TABLE `cs595_healthplandb`.`enrollment` (
  `Member_ID` INT NOT NULL,
  `Subscr_ID` INT NOT NULL,
  `Plan_ID` INT NOT NULL,
  `Enrl_Eff_Date` DATE NOT NULL,
  `Enrl_Term_Date` DATE NOT NULL,
  `Premium_Payment_Plan` VARCHAR(20) NOT NULL,
   UNIQUE INDEX `Member_ID_UNIQUE` (`Member_ID` ASC, `Subscr_ID` ASC, `Plan_ID` ASC, `Enrl_Eff_Date` ASC));



CREATE TABLE `cs595_healthplandb`.`premium_rate` (
  `Rate_Indx` INT NOT NULL,
  `Plan_ID` INT NOT NULL,
  `Member_Cov` VARCHAR(2) NOT NULL,
  `Plan_Prm_Rate`  DECIMAL(13,2) NOT NULL,
  PRIMARY KEY (`Rate_Indx`),
  UNIQUE INDEX `Rate_Indx_UNIQUE` (`Rate_Indx` ASC));
  
  CREATE TABLE `cs595_healthplandb`.`member_premium` (
  `Subscr_ID` INT NOT NULL,
  `Member_Count` INT NOT NULL,
  `Total_Premium` DECIMAL(13,2) NOT NULL,
  PRIMARY KEY (`Subscr_ID`),
  UNIQUE INDEX `Subscr_ID_UNIQUE` (`Subscr_ID` ASC));
  

CREATE TABLE `cs595_healthplandb`.`address` (
  `Subscr_ID` INT NOT NULL,
  `Address_SFX` VARCHAR(3) NOT NULL,
  `Address_1` VARCHAR(45) NOT NULL,
  `Address_2` VARCHAR(45) NULL,
  `City` VARCHAR(35) NULL,
  `State` VARCHAR(20) NULL,
  `Zip` INT NULL,
  PRIMARY KEY (`Address_SFX`, `Subscr_ID`),
  UNIQUE INDEX `Address_UNIQUE` (`Subscr_ID` ASC, `Address_SFX` ASC));
