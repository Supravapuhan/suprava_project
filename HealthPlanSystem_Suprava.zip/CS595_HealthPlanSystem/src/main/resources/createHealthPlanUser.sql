CREATE USER 'healthplandb_user'@'localhost' IDENTIFIED BY 'spring';

GRANT ALL PRIVILEGES ON cs595_healthplandb.* TO 'healthplandb_user'@'localhost' WITH GRANT OPTION;

SHOW GRANTS FOR 'healthplandb_user'@'localhost';